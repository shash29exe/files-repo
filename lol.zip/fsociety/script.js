const countDownDate = new Date();
countDownDate.setHours(countDownDate.getHours() + 14);
countDownDate.setMinutes(countDownDate.getMinutes() + 4);
countDownDate.setSeconds(countDownDate.getSeconds() + 8);

function updateTimer() {
    const now = new Date().getTime();

    const distance = countDownDate - now;

    const hours = Math.floor(distance / (1000 * 60 * 60));
    const minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
    const seconds = Math.floor((distance % (1000 * 60)) / 1000);
    
    document.getElementById("h").textContent = hours.toString().padStart(2, '0');
    document.getElementById("m").textContent = minutes.toString().padStart(2, '0');
    document.getElementById("s").textContent = seconds.toString().padStart(2, '0');
    
    if (distance < 0) {
        clearInterval(timerInterval);
        document.getElementById("hours").textContent = "00";
        document.getElementById("minutes").textContent = "00";
        document.getElementById("seconds").textContent = "00";
    }
}

updateTimer();

const timerInterval = setInterval(updateTimer, 1000);